﻿define(['EEye.Base'], function (base) {
    "option explicit";

    var configs = base.namespace('EEye.Configs');

    return (configs);
});
